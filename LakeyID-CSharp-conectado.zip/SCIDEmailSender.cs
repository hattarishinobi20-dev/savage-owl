namespace Supercell.Laser.Server.SCID
{
    using System.Net.Http.Headers;
    using System.Net.Http.Json;
    using Supercell.Laser.Server.Settings;

    internal static class SCIDEmailSender
    {
        // Keep a stalled provider from holding the SCID request open forever.
        private static readonly HttpClient HttpClient = new()
        {
            Timeout = TimeSpan.FromSeconds(10)
        };

        public static async Task<bool> SendCode(string identity, string pin)
        {
            Configuration configuration = Configuration.Instance;
            if (!configuration.ResendEnabled || string.IsNullOrWhiteSpace(configuration.ResendApiKey))
                return false;

            string email = GetEmail(identity);
            if (email == null || string.IsNullOrWhiteSpace(configuration.ResendFromEmail))
                return false;

            string from = string.IsNullOrWhiteSpace(configuration.ResendFromName)
                ? configuration.ResendFromEmail
                : $"{configuration.ResendFromName} <{configuration.ResendFromEmail}>";

            using HttpRequestMessage request = new(HttpMethod.Post, "https://api.resend.com/emails");
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", configuration.ResendApiKey);
            request.Content = JsonContent.Create(new
            {
                from,
                to = new[] { email },
                subject = $"Your verification code is {pin}",
                html = $"<p>Your verification code:</p><h1>{pin}</h1><p>The code expires in 5 minutes.</p>"
            });

            try
            {
                using HttpResponseMessage response = await HttpClient.SendAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    SCIDStart.Log($"verification email accepted by provider status={(int)response.StatusCode}");
                    return true;
                }

                // Do not persist provider response bodies: they can contain
                // request identifiers or account metadata. The status is
                // sufficient to diagnose delivery failures.
                SCIDStart.Log($"verification email provider rejected request status={(int)response.StatusCode}");
            }
            catch (Exception exception)
            {
                SCIDStart.Log($"verification email send failed: {exception.Message}");
            }

            return false;
        }

        private static string GetEmail(string identity)
        {
            const string prefix = "email:";
            return identity?.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) == true
                ? identity[prefix.Length..]
                : null;
        }
    }
}
