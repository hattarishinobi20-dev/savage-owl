# LakeyID + backend C#

O site em `Assets/` foi conectado às rotas do C# do pacote original. Deve ser servido pelo mesmo host do backend, pois usa URLs relativas `/api/...`. Ao executar o servidor hospedeiro, copie a pasta `Assets` para `SCID/Assets` ao lado do executável; `SCIDAssets.Register` usa esse caminho. Os arquivos C# devem ser integrados ao projeto do servidor `Supercell.Laser` que já possui os modelos e dependências usados por eles. Este pacote, como o original, não inclui `.csproj` nem o servidor inteiro.

Fluxo:
- LOG IN: `account/login` envia o código; `account/login.validate` verifica; `account/login.confirm` conclui e retorna token.
- CREATE ID: `account/create` envia o código; `account/create.confirm` verifica o código e cria a conta no momento de confirmar, pois o backend não fornece `create.validate`.
- Configurações chamam `account/settings.get`. O token e o e-mail ficam no `sessionStorage` da aba para validação da sessão. LOG OUT limpa os dados da aba, mas o backend original não possui rota de revogação de token; isso não encerra o token no servidor.

Para o envio funcionar, o projeto hospedeiro precisa inicializar o banco e configurar os campos `ResendEnabled`, `ResendApiKey`, `ResendFromEmail` e, opcionalmente, `ResendFromName`, com credenciais reais. O código foi ajustado para aguardar o envio, informar falha e aplicar o limitador de pedidos, ao invés de afirmar sucesso quando a entrega falha. Os códigos e tokens foram removidos das linhas de log alteradas.

O código original usa HTTPS na porta 7787 com caminhos de certificado específicos de outra máquina em `SCIDStart.cs`; substitua-os pelos caminhos do seu certificado e configure o servidor/proxy do seu ambiente. A URL deve servir tanto o site quanto `/api/` na mesma origem. Não exponha o serviço antes de revisão de segurança: o original gera tokens com `alg=none`, usa o endereço IP/`X-Forwarded-For` para localizar a conta do jogo e não possui revogação de token. A vinculação depende de uma sessão do jogo que o servidor C# consiga identificar; abrir o site não garante que a conta do jogo seja conectada.

`node test-interface.cjs` executa testes da interface contra respostas simuladas. O servidor C#, a entrega real de e-mail, o MySQL e a vinculação com o jogo não foram compilados nem testados, pois o projeto hospedeiro e suas dependências não estão neste repositório. Verifique-os em ambiente de teste antes do uso real.
