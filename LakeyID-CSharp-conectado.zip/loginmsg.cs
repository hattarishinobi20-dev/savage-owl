        public long AccountId;
        public string PassToken;
        public string DeviceId;
        public string Device;
        public bool isAndroid;
        public int RndKey;
        public string SupercellIdToken;

        public int Major;
        public int Minor;
        public int Build;

        public override void Decode()
        {
            AccountId = Stream.ReadLong();
            PassToken = Stream.ReadString();
            Major = Stream.ReadInt();
            Minor = Stream.ReadInt();
            Build = Stream.ReadInt();
            Stream.ReadString();
            DeviceId = Stream.ReadString();
            Stream.ReadVInt();
            Stream.ReadVInt();
            Stream.ReadString();
            Stream.ReadString();
            isAndroid = Stream.ReadBoolean();
            Stream.ReadString();
            Stream.ReadString();
            Stream.ReadBoolean();
            Stream.ReadString();
            RndKey = Stream.ReadInt();

            if (!Stream.IsAtEnd())
            {
                Stream.ReadVInt();

                if (!Stream.IsAtEnd())
                {
                    Stream.ReadString();

                    if (!Stream.IsAtEnd())
                    {
                        Stream.ReadStringReference(900000);
                        Stream.ReadStringReference(900000);
                        Stream.ReadVInt();

                        if (!Stream.IsAtEnd())
                        {
                            Stream.ReadStringReference(900000);
                            Stream.ReadStringReference(900000);
                            Stream.ReadStringReference(900000);

                            if (!Stream.IsAtEnd())
                            {
                                SupercellIdToken = LogicCompressedString.Decode(Stream)?.GetString();

                                if (!Stream.IsAtEnd())
                                    Stream.ReadBoolean();
                            }
                        }
                    }
                }
            }
            
// это желательно переделать под свою версию, это пример на с# на сервере Rolyale Brawl v32
// это LoginMessage / AttributionMessage 