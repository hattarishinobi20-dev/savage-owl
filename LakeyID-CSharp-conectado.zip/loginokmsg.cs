        public override void Encode()
        {
            Stream.WriteLong(AccountId); // 0, 1
            Stream.WriteLong(AccountId); // 0, 1

            Stream.WriteString(PassToken); // ""
            Stream.WriteString(null);
            Stream.WriteString(null);

            Stream.WriteInt(Major);
            Stream.WriteInt(Build);
            Stream.WriteInt(Minor);

            Stream.WriteString(ServerEnvironment);

            Stream.WriteInt(0);
            Stream.WriteInt(0);
            Stream.WriteInt(0);

            Stream.WriteString("");
            Stream.WriteString("");
            Stream.WriteString("");
            Stream.WriteInt(0);
            Stream.WriteString(null);
            Stream.WriteString("CA");
            Stream.WriteString(null);
            Stream.WriteInt(2);
            Stream.WriteString("");
            Stream.WriteInt(2);
            Stream.WriteString("");
            Stream.WriteString("");
            Stream.WriteInt(2);
            Stream.WriteString("");
            Stream.WriteString("");

            Stream.WriteVInt(0);
            LogicCompressedString.Encode(new LogicCompressedString(SCIDToken), Stream); // = PassToken
            Stream.WriteBoolean(true);
            Stream.WriteBoolean(false);
            Stream.WriteString(string.Empty); // 40-44 null
            Stream.WriteString(string.Empty);
            Stream.WriteString(string.Empty);
            Stream.WriteString(string.Empty);
            Stream.WriteString(string.Empty);
        }
        
// это нужно для SCID.zip, пытайтесь перенести (от 36 строки до 44) 
// это LoginOkMessage / AuthenticationOkMessage на Rolyale Brawl
// обезателен для скид